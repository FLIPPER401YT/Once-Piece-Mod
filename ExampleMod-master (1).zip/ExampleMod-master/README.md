An example mod for Necesse.

Check out the [modding wiki page](https://necessewiki.com/Modding) for more.